package com.example.demo.service;


import java.util.List;

import com.example.demo.entity.User;



public interface UserIService {
    
    public void insert(User user);

    public void update(User user) ;

    public User find(int id);
  
    public void delete(int id);
    
    public List<User> findAll();
}