package com.example.demo.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDao;
import com.example.demo.entity.User;
import com.example.demo.service.UserIService;


@Service
public class UserService implements UserIService{

    @Resource
    private UserDao userMapper;
    
    @Override
    public void insert(User user) {
        userMapper.insert(user);
    }

    public void update(User user) {
        userMapper.update(user);
    }

    public User find(int id) {
        return userMapper.find(id);
    }
    
    public void delete(int id){
        userMapper.delete(id);
    }

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userMapper.findAll();
	}
}