package com.example.demo.controller;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.impl.UserService;

/**
 * 鍦ㄥ畾涔変竴涓猂est鎺ュ彛鏃讹紝鎴戜滑閫氬父浼氫娇鐢℅ET锛孭OST锛孭UT锛孌ELETE鍑犵鏂瑰紡鏉ュ畬鎴愭垜浠墍闇�瑕佽繘琛孋RUD鐨勪竴浜涙搷浣滐紝
 * 鎴戜滑鍦ㄨ繖閲岀綏鍒楀拰鏁欏ぇ瀹跺湪瀹為檯寮�鍙戜腑鐨勪娇鐢紝涓�浜涘熀鏈蹇垫垜浠氨涓嶅啀璧樿堪锛屼緥濡備娇鐢≒OST鐨勪紭缂虹偣锛屽彲浣跨敤鍙傛暟鐨勫ぇ灏忛檺鍒剁瓑鍦帮細

    GET锛氫竴鑸敤浜庢煡璇㈡暟鎹紝涓嶅姙鍑芥暟鎹殑鏇存柊浠ュ強鎻掑叆鎿嶄綔銆傜敱浜庢槑鏂囦紶杈撶殑鍏崇郴锛屾垜浠竴鑸敤鏉ヨ幏鍙栦竴浜涙棤鍏崇敤鎴风殑淇℃伅銆�

    POST锛氫竴鑸敤浜庢暟鎹殑鎻掑叆鎿嶄綔锛屼篃鏄娇鐢ㄦ渶澶氱殑浼犺緭鏂瑰紡锛屼絾鏄湪H5璋冪敤鏃朵細鏈夎法鍩熺殑闂锛屼竴鑸娇鐢↗SONP鏉ヨВ鍐炽��

    PUT锛氭垜浠娇鐢≒UT鏂瑰紡鏉ュ鏁版嵁杩涜鏇存柊鎿嶄綔銆�

    DELETE锛氱敤浜庢暟鎹垹闄わ紝娉ㄦ剰鍦ㄦ暟鎹簱鍐呮槸閫昏緫鍒犻櫎锛堟敼鍙樻暟鎹姸鎬侊紝鐢ㄦ埛涓嶅啀鏌ヨ寰楀埌锛屼絾杩樹繚鐣欏湪鏁版嵁搴撳唴锛夎繕鏄墿鐞嗗垹闄わ紙鐪熷垹浜嗭級銆�

 * @author Administrator
 *
 */
@RestController
public class UserController{
    
    @Resource
    private UserService userService;

	public void insert(User user) {
		// TODO Auto-generated method stub
		
	}

	public void update(User user) {
		// TODO Auto-generated method stub
		
	}

	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}
	@GetMapping("find")
	public User find(int id) {
		// TODO Auto-generated method stub
		return userService.find(id);
	}
    
	@GetMapping("findAll")
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userService.findAll();
	}
}