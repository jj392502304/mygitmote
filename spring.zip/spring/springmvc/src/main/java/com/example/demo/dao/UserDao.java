package com.example.demo.dao;

import java.util.List;

import org.mybatis.spring.annotation.MapperScan;

import com.example.demo.entity.User;

@MapperScan
public interface UserDao {

    public void insert(User user);

    public void update(User user);
    
    public void delete(int id);
    
    public User find(int id);
    
    public List<User> findAll();
}